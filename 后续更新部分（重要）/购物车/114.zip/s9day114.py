s9day114 

内容回顾：
	1. 为什么要开发“学城”？
		- 提高在线 完课率（学成率）。
		- 具体：
			- 购买时间周期
			- 闯关式学习
			- 考核
			- 导师筛选
			- 导师监督（跟进记录）
			- 答疑时间（12小时）
			- 奖惩措施
				- 时间 
				- 作业 

	2. 开发周期和团队？
		团队：
			- 开发 
				- 导师后台，stark组件+rbac ： 1人
				- 管理后台，stark组件+rbac ： 1人
				- 主站
					- vue.js  1人 
					- api     村长+1/2文州+1/2Alex+其他 + 村长
			- 运维(1人)
			- 测试(1人)
			- 产品经理(1人)
			- UI设计(1人)
			- 运营(1人)
			- 销售(4人)
			- 全职导师(2人)
			- 签约讲师（...）
		周期：
			- 7月份
			- 11月份上线 
			- 11月份~次年5月份： 修Bug，活动支持，广告。。。
			- 6月份：开发题库系统
		
	3. 购买流程 
		- 加入购物车
		- 去结算
		- 去支付 
	
今日内容：
	- 去支付
	- Flask 
		- 基础
		- 第三方组件
		- 上下文管理聊源码

内容详细：
	1. 去支付（面向专题课）
		
		POST请求：
			URL:
				https://www.luffycity.com/course/order/?token=123879shdfkjshdf123
			请求体：
				{
					balance:1000,
					money:900
				}
		业务处理：
			...
	2. Flask 
		- pip3 install flask 
		
		- 短小精悍、可扩展强 的一个Web框架。
		
			注意：上下文管理机制
		
		- 依赖wsgi：werkzurg
		
		- 学习werkzurg：
			示例一：
				from werkzeug.wrappers import Request, Response
				from werkzeug.serving import run_simple

				def run(environ,start_response):

					return [b"asdfasdf"]

				if __name__ == '__main__':

					run_simple('localhost', 4000, run)
					
			示例二：
				from werkzeug.wrappers import Request, Response

				@Request.application
				def hello(request):
					return Response('Hello World!')

				if __name__ == '__main__':
					from werkzeug.serving import run_simple
					run_simple('localhost', 4000, hello)
		
		
		- 学习Flask

	
作业：
	"""
	1. 获取用户提交数据
			{
				balance:1000,
				money:900
			}
	   balance = request.data.get("balance")
	   money = request.data.get("money")
	   
	2. 数据验证
		- 大于等于0
		- 个人账户是否有1000贝里
		
		if user.auth.user.balance < balance:
			账户贝里余额不足
			
	优惠券ID_LIST = [1,3,4]
	总价
	实际支付
	3. 去结算中获取课程信息
		for course_dict in redis的结算中获取：
			# 获取课程ID
			# 根据course_id去数据库检查状态
			
			# 获取价格策略
			# 根据policy_id去数据库检查是否还依然存在
			
			# 获取使用优惠券ID
			# 根据优惠券ID检查优惠券是否过期
			
			# 获取原价+获取优惠券类型
				- 立减
					0 = 获取原价 - 优惠券金额
					或
					折后价格 = 获取原价 - 优惠券金额
				- 满减：是否满足限制
					折后价格 = 获取原价 - 优惠券金额
				- 折扣：
					折后价格 = 获取原价 * 80 / 100
					
	4. 全站优惠券
		- 去数据库校验全站优惠券的合法性
		- 应用优惠券：
			- 立减
				0 = 实际支付 - 优惠券金额
				或
				折后价格 =实际支付 - 优惠券金额
			- 满减：是否满足限制
				折后价格 = 实际支付 - 优惠券金额
			- 折扣：
				折后价格 = 实际支付 * 80 / 100
		- 实际支付
	5. 贝里抵扣
	
	6. 总金额校验
		实际支付 - 贝里 = money:900
	
	7. 为当前课程生成订单
		
			- 订单表创建一条数据 Order
				- 订单详细表创建一条数据 OrderDetail   EnrolledCourse
				- 订单详细表创建一条数据 OrderDetail   EnrolledCourse
				- 订单详细表创建一条数据 OrderDetail   EnrolledCourse
			
			- 如果有贝里支付
				- 贝里金额扣除  Account
				- 交易记录     TransactionRecord
			
			- 优惠券状态更新   CouponRecord
			
			注意：
				如果支付宝支付金额0，  表示订单状态：已支付
				如果支付宝支付金额110，表示订单状态：未支付
					- 生成URL（含订单号）
					- 回调函数：更新订单状态
				
	"""
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
