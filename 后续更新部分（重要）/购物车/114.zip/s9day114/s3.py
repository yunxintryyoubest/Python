class Foo(object):

    def __init__(self):
        print('sdfsdf')

    def __call__(self, *args, **kwargs):
        print('call')

obj = Foo()
obj()