from django.test import TestCase

# Create your tests here.


print("yuan_alex_egon".rsplit("_",2))